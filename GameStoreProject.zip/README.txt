Projeto: Gerência de Loja de Jogos (GameStoreProject)
Arquivos neste ZIP:
- GameStoreManagement.java : código-fonte principal (único arquivo .java)
Como compilar e executar:
1) Abra terminal na pasta onde está o arquivo .java
2) javac GameStoreManagement.java
3) java GameStoreManagement
O código demonstra: herança, polimorfismo, encapsulamento, agregação, sobrecarga de métodos e interfaces.
Grave um vídeo explicando cada parte do código e mostrando a execução.
