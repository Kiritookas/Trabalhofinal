/*
Gerência de Loja de Jogos - Projeto Java
Demonstra: Herança, Polimorfismo, Encapsulamento, Agregação, Sobrecarga de métodos, Interfaces

Arquivo principal: GameStoreManagement.java
Compile: javac GameStoreManagement.java
Execute: java GameStoreManagement
*/

import java.util.*;

// Interface: itens que podem ser vendidos
interface Sellable {
    double getPrice();
    String getName();
}

// Pessoa base (encapsulamento)
class Person {
    private String name;
    private String email;

    public Person(String name, String email) {
        this.name = name;
        this.email = email;
    }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    @Override
    public String toString() {
        return name + " <" + email + ">";
    }
}

// Employee herda Person e implementa comportamento de trabalho
class Employee extends Person {
    private int id;
    private String role;

    public Employee(int id, String name, String email, String role) {
        super(name, email);
        this.id = id;
        this.role = role;
    }

    public int getId() { return id; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public void work() {
        System.out.println(getName() + " está atendendo na loja como " + role + ".");
    }

    @Override
    public String toString() {
        return "[Emp#" + id + "] " + super.toString() + " (" + role + ")";
    }
}

// Manager é um Employee com responsabilidades extras (polimorfismo: override)
class Manager extends Employee {
    public Manager(int id, String name, String email) {
        super(id, name, email, "Manager");
    }

    @Override
    public void work() {
        System.out.println(getName() + " está gerenciando a loja e coordenando a equipe.");
    }

    // Sobrecarga: criar promoções de formas diferentes
    public void createPromotion(String description) {
        System.out.println(getName() + " criou uma promoção: " + description);
    }

    public void createPromotion(String description, double discountPercent) {
        System.out.println(getName() + " criou uma promoção: " + description + " com " + discountPercent + "% de desconto.");
    }
}

// Game implementa Sellable (encapsulamento dentro de Game)
class Game implements Sellable {
    private static int NEXT_ID = 1;
    private int id;
    private String title;
    private String platform;
    private double price;

    public Game(String title, String platform, double price) {
        this.id = NEXT_ID++;
        this.title = title;
        this.platform = platform;
        this.price = price;
    }

    public int getId() { return id; }
    @Override public double getPrice() { return price; }
    @Override public String getName() { return title; }

    public String getPlatform() { return platform; }
    public void setPrice(double price) { this.price = price; }

    @Override
    public String toString() {
        return "Game#" + id + ": " + title + " (" + platform + ") - R$ " + String.format(Locale.ROOT, \"%.2f\", price);
    }
}

// Bundle: exemplo de composição/agregação - pacote de jogos vendável
class Bundle implements Sellable {
    private String name;
    private List<Sellable> items = new ArrayList<>();

    public Bundle(String name) {
        this.name = name;
    }

    public void addItem(Sellable s) { items.add(s); }

    @Override
    public double getPrice() {
        double sum = 0;
        for (Sellable s : items) sum += s.getPrice();
        // exemplo: 10% desconto automático no bundle
        return sum * 0.90;
    }

    @Override
    public String getName() { return name; }

    @Override
    public String toString() {
        return "Bundle: " + name + " (itens=" + items.size() + ", preço R$ " + String.format(Locale.ROOT, \"%.2f\", getPrice()) + ")";
    }
}

// Customer
class Customer extends Person {
    private int customerId;
    public Customer(int id, String name, String email) {
        super(name, email);
        this.customerId = id;
    }
    public int getCustomerId() { return customerId; }

    @Override
    public String toString() { return \"Cliente#\" + customerId + \" - \" + super.toString(); }
}

// Sale: mostra agregação entre Customer, Employee e itens vendidos
class Sale {
    private static int NEXT_ID = 1;
    private int id;
    private Customer customer;
    private Employee seller;
    private List<Sellable> items = new ArrayList<>();
    private Date date;

    public Sale(Customer customer, Employee seller) {
        this.id = NEXT_ID++;
        this.customer = customer;
        this.seller = seller;
        this.date = new Date();
    }

    public void addItem(Sellable s) { items.add(s); }
    public double total() {
        double t = 0;
        for (Sellable s : items) t += s.getPrice();
        return t;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(\"Venda#\").append(id).append(\" em \").append(date).append(\"\\n\");
        sb.append(\"Cliente: \").append(customer).append(\"\\n\"); 
        sb.append(\"Vendedor: \").append(seller).append(\"\\n\");
        sb.append(\"Itens:\\n\");
        for (Sellable s : items) sb.append(\" - \").append(s.getName()).append(\" -> R$ \").append(String.format(Locale.ROOT, \"%.2f\", s.getPrice())).append(\"\\n\");
        sb.append(\"Total: R$ \").append(String.format(Locale.ROOT, \"%.2f\", total())).append(\"\\n\");
        return sb.toString();
    }
}

// Store: agregação de inventário e funcionários
class Store {
    private String name;
    private List<Game> inventory = new ArrayList<>();
    private List<Employee> employees = new ArrayList<>();
    private List<Sale> sales = new ArrayList<>();

    public Store(String name) {
        this.name = name;
    }

    // Sobrecarga: adicionar jogo de formas diferentes
    public void addGame(String title, String platform, double price) {
        addGame(new Game(title, platform, price));
    }
    public void addGame(Game g) {
        inventory.add(g);
        System.out.println(g.getName() + \" adicionado ao inventário.\");
    }

    public void removeGame(Game g) { inventory.remove(g); }

    public void hire(Employee e) {
        employees.add(e);
        System.out.println(e.getName() + \" contratado como \" + e.getRole() + \".\");
    }

    public void fire(Employee e) {
        employees.remove(e);
        System.out.println(e.getName() + \" demitido.\"); 
    }

    public List<Game> getInventory() { return Collections.unmodifiableList(inventory); }
    public List<Employee> getEmployees() { return Collections.unmodifiableList(employees); }

    public void recordSale(Sale s) {
        sales.add(s);
        System.out.println(\"Venda registrada: R$ \" + String.format(Locale.ROOT, \"%.2f\", s.total())); 
    }

    public void showStatus() {
        System.out.println(\"\\n=== Loja: \" + name + \" ===\");
        System.out.println(\"Inventário:\"); for (Game g : inventory) System.out.println(\" - \" + g);
        System.out.println(\"Funcionários:\"); for (Employee e : employees) System.out.println(\" - \" + e);
        System.out.println(\"Vendas realizadas: \" + sales.size());
    }
}

// Classe principal de demonstração
public class GameStoreManagement {
    public static void main(String[] args) {
        Store loja = new Store(\"Loja XP Games\");

        // Funcionários
        Employee emp1 = new Employee(1, \"Lucas\", \"lucas@loja.com\", \"Atendente\");
        Manager mgr = new Manager(2, \"Mariana\", \"mariana@loja.com\");

        loja.hire(emp1);
        loja.hire(mgr);

        // Inventário (sobrecarga utilizada)
        loja.addGame(\"The Legend of Java\", \"PC\", 199.90);
        loja.addGame(new Game(\"Super Code Bros\", \"Switch\", 249.50));
        loja.addGame(\"RPG do Futuro\", \"PS5\", 299.00);

        // Bundle exemplo
        Bundle bundle = new Bundle(\"Pacote Indie\");
        bundle.addItem(new Game(\"Indie One\", \"PC\", 39.90));
        bundle.addItem(new Game(\"Indie Two\", \"PC\", 49.90));
        loja.addGame(new Game(\"Collector's Item\", \"PC\", 59.90)); // jogo avulso
        // note: bundles are Sellable but not part of inventory Game list (could be promoted separately)

        // Cliente e venda (agregação entre customer, employee e itens)
        Customer cust = new Customer(100, \"Pedro\", \"pedro@mail.com\");
        Sale sale1 = new Sale(cust, emp1);
        // adicionar itens
        sale1.addItem(loja.getInventory().get(0));
        sale1.addItem(bundle); // vendendo bundle também
        loja.recordSale(sale1);

        // Manager cria promoção (sobrecarga)
        mgr.createPromotion(\"Desconto de fim de semana\", 15.0);

        // Polimorfismo: chamar work em lista de Employee
        for (Employee e : loja.getEmployees()) e.work();

        loja.showStatus();

        }
}
